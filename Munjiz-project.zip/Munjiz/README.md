# مُنجِز (Munjiz)

## قبل أول بناء
1. عدّل `Config.kt`: رقم الواتساب + رابط `version.json` (+ اختياري `STATS_URL`).
2. أنشئ مفتاح توقيع **مرة واحدة** واحتفظ به للأبد (بدونه التحديث فوق النسخة القديمة ما يشتغل):
   keytool -genkeypair -v -keystore release.jks -alias munjiz -keyalg RSA -keysize 2048 -validity 10000
   base64 -w0 release.jks   # انسخ الناتج
3. بـ GitHub: Settings → Secrets → Actions، أضف: KEYSTORE_B64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
4. ارفع المشروع على GitHub ← Actions ← Build APK ← Run workflow ← نزّل الـ APK من Artifacts.

## نشر تحديث جديد
1. ارفع `versionCode` (و versionName) في app/build.gradle.kts، وابنِ APK جديد.
2. ارفع الـ APK بـ GitHub Releases وانسخ رابط التحميل المباشر.
3. عدّل version.json: versionCode الجديد، apkUrl، notes.
   - forceUpdate=true: إجباري للجميع.
   - minVersionCode=N: أي نسخة أقل من N تصير إجبارية.
