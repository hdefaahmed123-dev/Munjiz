package com.hudhaifa.munjiz

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

object Updater {
    private fun currentVersion(a: Activity): Int {
        val i = a.packageManager.getPackageInfo(a.packageName, 0)
        @Suppress("DEPRECATION")
        return if (Build.VERSION.SDK_INT >= 28) i.longVersionCode.toInt() else i.versionCode
    }

    fun check(a: Activity) {
        Thread {
            try {
                val j = JSONObject(Net.get(Config.UPDATE_URL))
                val latest = j.getInt("versionCode")
                val min = j.optInt("minVersionCode", 0)
                val cur = currentVersion(a)
                if (latest > cur) {
                    val force = j.optBoolean("forceUpdate", false) || cur < min
                    a.runOnUiThread {
                        if (!a.isFinishing) show(a, j.getString("apkUrl"), j.optString("notes"), force)
                    }
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun show(a: Activity, url: String, notes: String, force: Boolean) {
        val b = AlertDialog.Builder(a)
            .setTitle(if (force) "تحديث إجباري" else "يتوفر تحديث جديد")
            .setMessage(notes.ifBlank { "يتوفر إصدار جديد من مُنجِز." })
            .setCancelable(!force)
            .setPositiveButton("تحديث", null)
        if (!force) b.setNegativeButton("لاحقاً", null)
        val d = b.create()
        d.setCanceledOnTouchOutside(!force)
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            d.dismiss()
            download(a, url)
        }
    }

    private fun download(a: Activity, url: String) {
        if (Build.VERSION.SDK_INT >= 26 && !a.packageManager.canRequestPackageInstalls()) {
            a.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${a.packageName}"))
            )
            android.widget.Toast.makeText(a, "فعّل السماح بالتثبيت من هذا التطبيق ثم ارجع", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val pb = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val box = LinearLayout(a).apply { setPadding(a.dp(24), a.dp(16), a.dp(24), a.dp(16)); addView(pb, LinearLayout.LayoutParams(-1, -2)) }
        val d = AlertDialog.Builder(a).setTitle("جارٍ تنزيل التحديث...").setView(box).setCancelable(false).create()
        d.show()
        Thread {
            try {
                val dir = File(a.cacheDir, "updates").apply { mkdirs() }
                val f = File(dir, "update.apk")
                val c = Net.open(url)
                val total = c.contentLength
                var read = 0L
                c.inputStream.use { ins ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            read += n
                            if (total > 0) a.runOnUiThread { pb.progress = (read * 100 / total).toInt() }
                        }
                    }
                }
                a.runOnUiThread {
                    d.dismiss()
                    val uri = FileProvider.getUriForFile(a, "${a.packageName}.fp", f)
                    a.startActivity(
                        Intent(Intent.ACTION_VIEW)
                            .setDataAndType(uri, "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                }
            } catch (e: Exception) {
                a.runOnUiThread {
                    d.dismiss()
                    android.widget.Toast.makeText(a, "فشل تنزيل التحديث، تأكد من الإنترنت", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
