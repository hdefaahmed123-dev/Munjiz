package com.hudhaifa.munjiz

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

object Summarizer {
    private val stop = setOf(
        "في", "من", "على", "إلى", "الى", "عن", "أن", "ان", "إن", "هذا", "هذه", "ذلك", "التي", "الذي", "كان", "كانت",
        "ما", "لا", "هو", "هي", "ثم", "أو", "او", "كما", "قد", "مع", "بين", "كل", "تم",
        "the", "and", "for", "are", "was", "were", "with", "that", "this", "from", "which", "its", "has", "have"
    )
    private val words = Regex("[\\p{L}\\p{N}]+")

    private fun toks(s: String) = words.findAll(s.lowercase()).map { it.value }.filter { it.length > 2 && it !in stop }.toList()

    fun summarize(text: String, ratio: Double): List<String> {
        val sents = text.split(Regex("(?<=[.!?؟])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 25 }
        if (sents.size <= 3) return sents
        val freq = HashMap<String, Int>()
        sents.forEach { s -> toks(s).forEach { w -> freq[w] = (freq[w] ?: 0) + 1 } }
        val scored = sents.mapIndexed { i, s ->
            val t = toks(s)
            val sc = if (t.isEmpty()) 0.0 else t.sumOf { (freq[it] ?: 0).toDouble() } / Math.sqrt(t.size.toDouble())
            Triple(i, s, sc)
        }
        val k = maxOf(3, (sents.size * ratio).toInt())
        return scored.sortedByDescending { it.third }.take(k).sortedBy { it.first }.map { it.second }
    }
}

class SummarizeActivity : ComponentActivity() {
    private lateinit var input: EditText
    private lateinit var out: TextView
    private lateinit var status: TextView
    private lateinit var saveRow: LinearLayout
    private var result: List<String> = emptyList()

    private val filePick = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u == null) return@registerForActivityResult
        status.text = "جارٍ قراءة الملف..."
        Thread {
            try {
                val t = FileText.paragraphs(this, u).joinToString("\n")
                runOnUiThread { input.setText(t); status.text = "تم تحميل النص (${t.length} حرف)" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر قراءة الملف" }
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screen("تلخيص ملزمة") {
            addView(btn("📄 اختيار ملف (docx / pdf / txt)") { filePick.launch("*/*") })
            input = edit("أو الصق النص هنا", 8); addView(input)
            val level = spinner(listOf("مختصر", "وسط", "شامل")).apply { setSelection(1) }
            addView(tv("مستوى التلخيص", 14f)); addView(level)
            status = tv("", 13f, false, Color.GRAY); addView(status)
            addView(btn("لخّص") {
                val t = input.text.toString()
                if (t.isBlank()) { status.text = "ماكو نص للتلخيص"; return@btn }
                val ratio = doubleArrayOf(0.12, 0.25, 0.45)[level.selectedItemPosition]
                result = Summarizer.summarize(t, ratio)
                out.text = result.joinToString("\n\n• ", prefix = "• ")
                status.text = "تم التلخيص (${result.size} جملة)"
                saveRow.visibility = View.VISIBLE
            })
            out = tv("", 16f); addView(out)
            saveRow = LinearLayout(this@SummarizeActivity).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            val blocks = { listOf<Block>(Block.Title("ملخص الملزمة", 24f)) + result.map { Block.P("• $it") } }
            saveRow.addView(btn("تحويل إلى Word") {
                Files.saveAndOpen(this@SummarizeActivity, "ملخص.docx", Files.DOCX, Docx.build(blocks(), Style()))
            })
            saveRow.addView(btn("تحويل إلى PDF") {
                Files.saveAndOpen(this@SummarizeActivity, "ملخص.pdf", Files.PDF, PdfOut.build(blocks(), Style()))
            })
            addView(saveRow)
        }
    }
}
