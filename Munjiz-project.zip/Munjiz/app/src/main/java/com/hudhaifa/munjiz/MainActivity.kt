package com.hudhaifa.munjiz

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT <= 28) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        screen("مُنجِز") {
            addView(tv("تم التطوير بواسطة المهندس حذيفة\nللتواصل معه عبر واتساب اضغط هنا 💬", 14f, false, Color.parseColor("#1565C0")).apply {
                setOnClickListener { openWhatsApp(this@MainActivity) }
            })
            addView(btn("📝 تقرير جديد") { go(ReportActivity::class.java) })
            addView(btn("🌐 الترجمة الفورية (نص / ملف / كاميرا)") { go(TranslateActivity::class.java) })
            addView(btn("📖 القاموس (إنكليزي ← عربي + نطق)") {
                startActivity(Intent(this@MainActivity, TranslateActivity::class.java).putExtra("dict", true))
            })
            addView(btn("🗒️ تلخيص ملزمة") { go(SummarizeActivity::class.java) })
            addView(btn("🔁 تحويل Word ↔ PDF") { go(ConvertActivity::class.java) })
        }
        pingFirstRun()
    }

    override fun onResume() {
        super.onResume()
        Updater.check(this)
    }

    private fun go(c: Class<*>) = startActivity(Intent(this, c))

    private fun pingFirstRun() {
        val p = getSharedPreferences("m", MODE_PRIVATE)
        if (Config.STATS_URL.isNotEmpty() && !p.getBoolean("pinged", false)) {
            Thread {
                try { Net.get(Config.STATS_URL); p.edit().putBoolean("pinged", true).apply() } catch (e: Exception) { }
            }.start()
        }
    }
}
