package com.hudhaifa.munjiz

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

sealed class Block {
    data class Title(val t: String, val size: Float = 26f) : Block()
    data class Center(val t: String) : Block()
    data class H(val t: String) : Block()
    data class P(val t: String) : Block()
    class Img(val jpeg: ByteArray) : Block()
    object Break : Block()
    object Gap : Block()
}

data class Style(val size: Float = 14f, val color: Int = Color.BLACK, val bold: Boolean = false, val rtl: Boolean = true)

object Docs {
    fun toJpeg(raw: ByteArray): ByteArray? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(raw, 0, raw.size, o)
        if (o.outWidth <= 0) return null
        val s = maxOf(1, o.outWidth / 1200)
        val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: return null
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        return bos.toByteArray()
    }
}

object Docx {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

    private fun par(t: String, sz: Float, bold: Boolean, jc: String, col: String, rtl: Boolean): String {
        val half = (sz * 2).toInt()
        return "<w:p><w:pPr>${if (rtl) "<w:bidi/>" else ""}<w:spacing w:after=\"120\" w:line=\"360\" w:lineRule=\"auto\"/><w:jc w:val=\"$jc\"/></w:pPr>" +
            "<w:r><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/>${if (bold) "<w:b/><w:bCs/>" else ""}" +
            "<w:color w:val=\"$col\"/><w:sz w:val=\"$half\"/><w:szCs w:val=\"$half\"/>${if (rtl) "<w:rtl/>" else ""}</w:rPr>" +
            "<w:t xml:space=\"preserve\">${esc(t)}</w:t></w:r></w:p>"
    }

    private fun drawing(rid: String, id: Int, cx: Long, cy: Long) =
        "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
            "<wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:docPr id=\"$id\" name=\"img$id\"/>" +
            "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">" +
            "<a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:nvPicPr><pic:cNvPr id=\"$id\" name=\"img$id.jpeg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"$rid\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>" +
            "</wp:inline></w:drawing></w:r></w:p>"

    fun build(blocks: List<Block>, st: Style): ByteArray {
        val bos = ByteArrayOutputStream()
        val z = ZipOutputStream(bos)
        fun put(name: String, data: ByteArray) { z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry() }

        val body = StringBuilder()
        val rels = StringBuilder()
        val media = ArrayList<Pair<String, ByteArray>>()
        val col = hex(st.color)
        var n = 0
        for (b in blocks) {
            when (b) {
                is Block.Title -> body.append(par(b.t, b.size, true, "center", "0D47A1", st.rtl))
                is Block.Center -> body.append(par(b.t, st.size + 2, false, "center", col, st.rtl))
                is Block.H -> body.append(par(b.t, st.size + 4, true, "both", "0D47A1", st.rtl))
                is Block.P -> body.append(par(b.t, st.size, st.bold, "both", col, st.rtl))
                is Block.Img -> {
                    n++
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(b.jpeg, 0, b.jpeg.size, o)
                    if (o.outWidth > 0) {
                        var cx = 4320000L
                        var cy = cx * o.outHeight / o.outWidth
                        if (cy > 5400000L) { cx = cx * 5400000L / cy; cy = 5400000L }
                        val fn = "img$n.jpeg"
                        media.add(fn to b.jpeg)
                        rels.append("<Relationship Id=\"rId$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$fn\"/>")
                        body.append(drawing("rId$n", n, cx, cy))
                    }
                }
                Block.Break -> body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
                Block.Gap -> body.append("<w:p/>")
            }
        }
        val sect = "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>${if (st.rtl) "<w:bidi/>" else ""}</w:sectPr>"
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\"><w:body>$body$sect</w:body></w:document>"

        put("[Content_Types].xml", ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>").toByteArray())
        put("_rels/.rels", ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>").toByteArray())
        put("word/_rels/document.xml.rels", ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">$rels</Relationships>").toByteArray())
        put("word/document.xml", doc.toByteArray(Charsets.UTF_8))
        for ((fn, data) in media) put("word/media/$fn", data)
        z.close()
        return bos.toByteArray()
    }
}

object PdfOut {
    private const val W = 595
    private const val H = 842
    private const val M = 48

    fun build(blocks: List<Block>, st: Style): ByteArray {
        val doc = PdfDocument()
        var page: PdfDocument.Page? = null
        var cv: Canvas? = null
        var pageNo = 0
        var y = M.toFloat()
        val cw = W - 2 * M

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            page = p
            cv = p.canvas
            y = M.toFloat()
        }
        fun paint(size: Float, bold: Boolean, color: Int) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        fun text(t: String, size: Float, bold: Boolean, color: Int, align: Layout.Alignment, gap: Float) {
            val l = StaticLayout.Builder.obtain(t, 0, t.length, paint(size, bold, color), cw)
                .setAlignment(align).setLineSpacing(0f, 1.35f).build()
            for (i in 0 until l.lineCount) {
                val top = l.getLineTop(i)
                val bot = l.getLineBottom(i)
                if (y + (bot - top) > H - M) newPage()
                val c = cv!!
                c.save()
                c.translate(M.toFloat(), y - top)
                c.clipRect(0f, top.toFloat(), cw.toFloat(), bot.toFloat())
                l.draw(c)
                c.restore()
                y += (bot - top)
            }
            y += gap
        }

        newPage()
        val blue = Color.parseColor("#0D47A1")
        for (b in blocks) {
            when (b) {
                is Block.Title -> text(b.t, b.size, true, blue, Layout.Alignment.ALIGN_CENTER, 14f)
                is Block.Center -> text(b.t, st.size + 2, false, st.color, Layout.Alignment.ALIGN_CENTER, 8f)
                is Block.H -> text(b.t, st.size + 4, true, blue, Layout.Alignment.ALIGN_NORMAL, 6f)
                is Block.P -> text(b.t, st.size, st.bold, st.color, Layout.Alignment.ALIGN_NORMAL, 8f)
                is Block.Img -> {
                    val bmp = BitmapFactory.decodeByteArray(b.jpeg, 0, b.jpeg.size)
                    if (bmp != null) {
                        val w = minOf(cw * 0.7f, bmp.width.toFloat())
                        val h = w * bmp.height / bmp.width
                        if (y + h > H - M) newPage()
                        val left = M + (cw - w) / 2
                        cv!!.drawBitmap(bmp, null, RectF(left, y, left + w, y + h), null)
                        y += h + 12f
                    }
                }
                Block.Break -> newPage()
                Block.Gap -> y += 24f
            }
        }
        page?.let { doc.finishPage(it) }
        val bos = ByteArrayOutputStream()
        doc.writeTo(bos)
        doc.close()
        return bos.toByteArray()
    }
}
