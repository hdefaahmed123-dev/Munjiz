package com.hudhaifa.munjiz

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.AdapterView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale

class TranslateActivity : ComponentActivity() {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var dir: Spinner
    private lateinit var status: TextView
    private lateinit var saveRow: LinearLayout
    private var translator: Translator? = null
    private var curKey = ""
    private var ready = false
    private var pendingParas: List<String>? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val h = Handler(Looper.getMainLooper())
    private var lastBlocks: List<Block>? = null
    private var lastStyle = Style()
    private val camFile by lazy { File(cacheDir, "cam/cam.jpg").also { it.parentFile?.mkdirs() } }
    private val isEn2Ar get() = dir.selectedItemPosition == 0

    private val filePick = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) translateFile(u)
    }
    private val camLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) ocr()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dict = intent.getBooleanExtra("dict", false)
        tts = TextToSpeech(this) { ttsOk = it == TextToSpeech.SUCCESS }
        screen(if (dict) "قاموس إنكليزي ← عربي" else "الترجمة الفورية") {
            dir = spinner(listOf("إنكليزي ← عربي", "عربي ← إنكليزي"))
            if (dict) dir.visibility = View.GONE
            addView(dir)
            input = edit(if (dict) "اكتب الكلمة بالإنكليزية" else "اكتب النص هنا", if (dict) 1 else 5)
            addView(input)
            status = tv("", 13f, false, Color.GRAY); addView(status)
            output = tv("", 20f, true, Color.parseColor("#0D47A1")); addView(output)
            addView(btn("🔊 نطق (الإنكليزية)") { speak() })
            addView(btn("📷 ترجمة من الكاميرا (إنكليزي فقط)") {
                if (!isEn2Ar) {
                    Toast.makeText(this@TranslateActivity, "التعرف على الحروف بالكاميرا يدعم الإنكليزية فقط", Toast.LENGTH_LONG).show()
                } else {
                    val u = FileProvider.getUriForFile(this@TranslateActivity, "$packageName.fp", camFile)
                    camLauncher.launch(u)
                }
            })
            if (!dict) addView(btn("📄 ترجمة ملف (txt / docx / pdf)") { filePick.launch("*/*") })
            saveRow = LinearLayout(this@TranslateActivity).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            saveRow.addView(btn("حفظ الترجمة Word") {
                lastBlocks?.let { Files.saveAndOpen(this@TranslateActivity, "ترجمة.docx", Files.DOCX, Docx.build(it, lastStyle)) }
            })
            saveRow.addView(btn("حفظ الترجمة PDF") {
                lastBlocks?.let { Files.saveAndOpen(this@TranslateActivity, "ترجمة.pdf", Files.PDF, PdfOut.build(it, lastStyle)) }
            })
            addView(saveRow)
        }
        input.doAfterTextChanged { schedule() }
        dir.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                ready = false; curKey = ""; schedule()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun schedule() {
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ translateNow() }, 300)
    }

    private fun ensure() {
        val src = if (isEn2Ar) TranslateLanguage.ENGLISH else TranslateLanguage.ARABIC
        val tgt = if (isEn2Ar) TranslateLanguage.ARABIC else TranslateLanguage.ENGLISH
        val key = "$src$tgt"
        if (key == curKey) return // التجهيز شغّال
        translator?.close()
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        translator = t
        curKey = key
        ready = false
        status.text = "جارٍ تجهيز حزمة اللغة (تحتاج إنترنت مرة واحدة فقط)..."
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                ready = true
                status.text = "جاهز ✅ يعمل بدون إنترنت"
                translateNow()
                pendingParas?.let { p -> pendingParas = null; runChain(p) }
            }
            .addOnFailureListener {
                curKey = ""
                status.text = "فشل تحميل حزمة اللغة، تأكد من الإنترنت لأول مرة"
            }
    }

    private fun translateNow() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) { output.text = ""; return }
        if (!ready || translator == null) { ensure(); return }
        translator!!.translate(t).addOnSuccessListener {
            if (input.text.toString().trim() == t) output.text = it
        }
    }

    private fun speak() {
        val txt = if (isEn2Ar) input.text.toString() else output.text.toString()
        if (txt.isBlank() || !ttsOk) return
        tts?.language = Locale.US
        tts?.speak(txt, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "m")
    }

    private fun ocr() {
        try {
            val img = InputImage.fromFilePath(this, Uri.fromFile(camFile))
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
                .addOnSuccessListener { input.setText(it.text) }
                .addOnFailureListener { status.text = "تعذر قراءة النص من الصورة" }
        } catch (e: Exception) { status.text = "تعذر قراءة الصورة" }
    }

    private fun translateFile(uri: Uri) {
        status.text = "جارٍ قراءة الملف..."
        Thread {
            val paras = try { FileText.paragraphs(this, uri) } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر قراءة الملف" }
                return@Thread
            }
            runOnUiThread {
                if (paras.isEmpty()) { status.text = "الملف فارغ أو غير مدعوم"; return@runOnUiThread }
                if (ready && translator != null) runChain(paras) else { pendingParas = paras; ensure() }
            }
        }.start()
    }

    private fun runChain(paras: List<String>) {
        val res = ArrayList<String>()
        fun next(i: Int) {
            if (i >= paras.size) { finishFile(res); return }
            translator!!.translate(paras[i])
                .addOnSuccessListener { res.add(it); status.text = "ترجمة ${i + 1}/${paras.size}"; next(i + 1) }
                .addOnFailureListener { res.add(paras[i]); next(i + 1) }
        }
        next(0)
    }

    private fun finishFile(res: List<String>) {
        lastStyle = Style(rtl = isEn2Ar)
        lastBlocks = res.map { Block.P(it) }
        output.text = res.take(3).joinToString("\n\n") + if (res.size > 3) "\n..." else ""
        status.text = "تمت ترجمة الملف ✅"
        saveRow.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        super.onDestroy()
        translator?.close()
        tts?.shutdown()
    }
}
