package com.hudhaifa.munjiz

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import java.io.ByteArrayOutputStream

object Diagrams {
    private fun base(): Pair<Bitmap, Canvas> {
        val b = Bitmap.createBitmap(640, 380, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.WHITE)
        return b to c
    }
    private fun pen() = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; strokeWidth = 4f; style = Paint.Style.STROKE }
    private fun txt() = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0D47A1"); textSize = 30f; textAlign = Paint.Align.CENTER }
    private fun jpeg(b: Bitmap): ByteArray { val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 90, o); return o.toByteArray() }

    private fun frame(c: Canvas, p: Paint, rightX: Float) {
        c.drawLine(100f, 90f, 200f, 90f, p)
        c.drawLine(rightX, 90f, rightX, 290f, p)
        c.drawLine(rightX, 290f, 100f, 290f, p)
        c.drawLine(100f, 90f, 100f, 170f, p)
        c.drawLine(100f, 210f, 100f, 290f, p)
        c.drawLine(70f, 170f, 130f, 170f, p)   // قطب موجب (طويل)
        c.drawLine(85f, 210f, 115f, 210f, p)   // قطب سالب (قصير)
    }

    private fun zigzag(c: Canvas, p: Paint) {
        val path = Path()
        path.moveTo(200f, 90f)
        var x = 200f
        for (i in 0 until 12) { x += 20f; path.lineTo(x, if (i % 2 == 0) 60f else 120f) }
        path.lineTo(440f, 90f)
        c.drawPath(path, p)
    }

    fun resistor(): ByteArray {
        val (b, c) = base(); val p = pen(); val t = txt()
        frame(c, p, 540f); zigzag(c, p)
        c.drawLine(440f, 90f, 540f, 90f, p)
        c.drawText("R", 320f, 40f, t); c.drawText("V", 45f, 200f, t); c.drawText("I", 320f, 330f, t)
        return jpeg(b)
    }

    fun diode(): ByteArray {
        val (b, c) = base(); val p = pen(); val t = txt()
        frame(c, p, 540f); zigzag(c, p)
        c.drawLine(440f, 90f, 540f, 90f, p)
        // الدايود: مثلث + خط على الفرع الأيمن
        c.drawLine(540f, 90f, 540f, 160f, p)
        val tri = Path().apply { moveTo(510f, 160f); lineTo(570f, 160f); lineTo(540f, 210f); close() }
        c.drawPath(tri, p)
        c.drawLine(510f, 210f, 570f, 210f, p)
        c.drawLine(540f, 210f, 540f, 290f, p)
        c.drawText("R", 320f, 40f, t); c.drawText("Vin", 45f, 200f, t); c.drawText("D", 600f, 195f, t)
        return jpeg(b)
    }
}

object Extras {
    private data class Topic(val keys: List<String>, val title: String, val formulas: List<String>, val diagram: (() -> ByteArray)?)

    private val topics = listOf(
        Topic(
            listOf("دايود", "ديود", "زينر", "diode", "zener", "مقوم", "مقلم"),
            "القوانين والمعادلات (الدايود)",
            listOf(
                "جهد الحاجز: السيليكون ≈ 0.7 V ، الجرمانيوم ≈ 0.3 V",
                "تيار الدايود: I = (Vin − VD) / R",
                "منظم زينر: IR = IZ + IL ، و VOUT = VZ",
                "جهد المقوم النصفي: Vdc = Vm / π"
            ),
            { Diagrams.diode() }
        ),
        Topic(
            listOf("كهرب", "مقاوم", "فولت", "تيار", "دائرة", "دوائر", "ohm", "resist", "voltage", "circuit"),
            "القوانين والمعادلات (الدوائر الكهربائية)",
            listOf(
                "قانون أوم: V = I × R",
                "القدرة الكهربائية: P = V × I = I² × R",
                "المقاومة المكافئة على التوالي: Req = R1 + R2 + … + Rn",
                "المقاومة المكافئة على التوازي: 1/Req = 1/R1 + 1/R2 + … + 1/Rn"
            ),
            { Diagrams.resistor() }
        ),
        Topic(
            listOf("اتصالات", "تردد", "موجة", "موجات", "frequency", "wave", "signal"),
            "القوانين والمعادلات (الاتصالات والموجات)",
            listOf(
                "التردد والزمن الدوري: f = 1 / T",
                "سرعة الموجة: c = λ × f",
                "الكسب بالديسيبل: dB = 10 × log10(P2 / P1)"
            ),
            null
        ),
        Topic(
            listOf("سرعة", "حركة", "قوة", "فيزياء", "velocity", "force", "physics"),
            "القوانين والمعادلات (الحركة)",
            listOf("السرعة: v = d / t", "التسارع: a = Δv / t", "القوة: F = m × a"),
            null
        ),
        Topic(
            listOf("جغرافية", "نقل", "سكان", "تجارة", "geography", "population", "transport"),
            "القوانين والمعادلات (الجغرافية)",
            listOf(
                "الكثافة السكانية = عدد السكان ÷ المساحة",
                "معدل التغير % = ((القيمة الجديدة − القيمة القديمة) ÷ القيمة القديمة) × 100"
            ),
            null
        )
    )

    fun forTopic(topic: String): List<Block> {
        val t = topic.lowercase()
        val m = topics.firstOrNull { tp -> tp.keys.any { t.contains(it) } } ?: return emptyList()
        val out = ArrayList<Block>()
        out.add(Block.H(m.title))
        m.formulas.forEach { out.add(Block.Center(it)) }
        m.diagram?.let { out.add(Block.Img(it())) }
        return out
    }
}
