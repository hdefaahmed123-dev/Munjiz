package com.hudhaifa.munjiz

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Config {
    // رقمك بصيغة دولية بدون + وبدون صفر (مثال: 9647701234567)
    const val WHATSAPP = "9647739415341"
    // رابط ملف version.json الخام (مثلاً من GitHub)
    const val UPDATE_URL = "https://raw.githubusercontent.com/hdefaaahmed123-dev/munjiz/main/version.json"
    // اختياري: رابط عدّاد يُستدعى مرة واحدة عند أول تشغيل (لمعرفة عدد من ثبّتوا التطبيق)
    const val STATS_URL = ""
}

object Net {
    fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 25000
            setRequestProperty("User-Agent", "MunjizApp/1.0 (student project)")
        }

    fun get(url: String): String = open(url).inputStream.bufferedReader().use { it.readText() }
    fun bytes(url: String): ByteArray = open(url).inputStream.use { it.readBytes() }

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

object Files {
    const val DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val PDF = "application/pdf"

    fun save(ctx: Context, name: String, mime: String, data: ByteArray): Uri? {
        return if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Munjiz")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
            uri
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Munjiz")
            dir.mkdirs()
            val f = File(dir, name)
            f.writeBytes(data)
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fp", f)
        }
    }

    fun saveAndOpen(ctx: Context, name: String, mime: String, data: ByteArray) {
        val uri = try { save(ctx, name, mime, data) } catch (e: Exception) { null }
        if (uri == null) {
            Toast.makeText(ctx, "تعذر حفظ الملف (تحقق من صلاحية التخزين)", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(ctx, "تم الحفظ في التنزيلات ← Munjiz", Toast.LENGTH_LONG).show()
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { /* ماكو تطبيق يفتحه، الملف محفوظ */ }
    }
}

fun openWhatsApp(ctx: Context) {
    val msg = Uri.encode("مرحباً م. حذيفة، عندي استفسار عن تطبيق مُنجِز")
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${Config.WHATSAPP}?text=$msg")))
    } catch (e: Exception) { }
}
