package com.hudhaifa.munjiz

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

object FileText {
    fun name(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i) ?: ""
            }
        }
        return uri.lastPathSegment ?: ""
    }

    fun paragraphs(ctx: Context, uri: Uri): List<String> {
        val n = name(ctx, uri).lowercase()
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        return when {
            n.endsWith(".docx") -> docx(bytes)
            n.endsWith(".pdf") -> pdf(ctx, bytes)
            else -> String(bytes, Charsets.UTF_8).split(Regex("\\r?\\n")).map { it.trim() }.filter { it.isNotEmpty() }
        }
    }

    private fun unesc(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    fun docx(bytes: ByteArray): List<String> {
        val z = ZipInputStream(ByteArrayInputStream(bytes))
        var e = z.nextEntry
        val rx = Regex("<w:t(?: [^>]*)?>([^<]*)</w:t>")
        while (e != null) {
            if (e.name == "word/document.xml") {
                val xml = String(z.readBytes(), Charsets.UTF_8)
                return xml.split("</w:p>")
                    .map { p -> rx.findAll(p).joinToString("") { unesc(it.groupValues[1]) }.trim() }
                    .filter { it.isNotEmpty() }
            }
            e = z.nextEntry
        }
        return emptyList()
    }

    fun pdf(ctx: Context, bytes: ByteArray): List<String> {
        PDFBoxResourceLoader.init(ctx)
        val text = PDDocument.load(bytes).use { PDFTextStripper().getText(it) }
        val lines = text.split(Regex("\\r?\\n")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (l in lines) {
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(l)
            if (l.last() in ".!?؟:") { out.add(cur.toString()); cur = StringBuilder() }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}
