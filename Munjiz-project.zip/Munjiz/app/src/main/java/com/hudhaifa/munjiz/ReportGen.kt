package com.hudhaifa.munjiz

import org.json.JSONObject
import java.net.URLEncoder
import java.util.Calendar

data class Opts(
    val topic: String, val pages: Int, val style: Style,
    val uni: String, val college: String, val dept: String,
    val student: String, val supervisor: String,
    val images: Boolean, val extraImages: List<ByteArray>
)

object Wiki {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    fun lang(q: String) = if (q.any { it in '\u0600'..'\u06FF' }) "ar" else "en"

    fun search(q: String, lang: String): List<String> {
        val j = JSONObject(Net.get("https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=${enc(q)}&srlimit=8&format=json"))
        val arr = j.getJSONObject("query").getJSONArray("search")
        return (0 until arr.length()).map { arr.getJSONObject(it).getString("title") }
    }

    private fun firstPage(j: JSONObject): JSONObject {
        val pages = j.getJSONObject("query").getJSONObject("pages")
        return pages.getJSONObject(pages.keys().next())
    }

    fun paragraphs(title: String, lang: String): List<String> {
        val j = JSONObject(Net.get("https://$lang.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exsectionformat=plain&redirects=1&format=json&titles=${enc(title)}"))
        val txt = firstPage(j).optString("extract", "")
        return txt.split("\n").map { it.replace(Regex("\\[\\d+\\]"), "").trim() }.filter { it.length >= 40 }
    }

    fun imageList(q: String, lang: String): List<Pair<String, String>> {
        val j = JSONObject(Net.get("https://$lang.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${enc(q)}&gsrlimit=12&prop=pageimages&piprop=thumbnail&pithumbsize=600&format=json"))
        val pages = j.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val src = p.optJSONObject("thumbnail")?.optString("source")
            if (!src.isNullOrEmpty()) out.add(p.getString("title") to src)
        }
        return out
    }

    fun image(title: String, lang: String): ByteArray? = try {
        val j = JSONObject(Net.get("https://$lang.wikipedia.org/w/api.php?action=query&prop=pageimages&piprop=thumbnail&pithumbsize=600&redirects=1&format=json&titles=${enc(title)}"))
        val src = firstPage(j).optJSONObject("thumbnail")?.optString("source")
        if (src.isNullOrEmpty()) null else Docs.toJpeg(Net.bytes(src))
    } catch (e: Exception) { null }
}

object ReportGen {
    fun build(o: Opts, online: Boolean, progress: (Int) -> Unit): List<Block> {
        val st = o.style
        val cpp = (2400.0 * (12.0 / st.size) * (12.0 / st.size)).toInt()
        val cover = o.pages >= 3
        val out = ArrayList<Block>()

        if (cover) {
            if (o.uni.isNotBlank()) out.add(Block.Title(o.uni, 24f))
            if (o.college.isNotBlank()) out.add(Block.Center(o.college))
            if (o.dept.isNotBlank()) out.add(Block.Center(o.dept))
            repeat(4) { out.add(Block.Gap) }
            out.add(Block.Title(o.topic, 30f))
            repeat(4) { out.add(Block.Gap) }
            if (o.student.isNotBlank()) out.add(Block.Center("إعداد الطالب/ة: ${o.student}"))
            if (o.supervisor.isNotBlank()) out.add(Block.Center("بإشراف: ${o.supervisor}"))
            out.add(Block.Center(Calendar.getInstance().get(Calendar.YEAR).toString()))
            out.add(Block.Break)
        } else out.add(Block.Title(o.topic, 22f))

        if (!online) {
            out.addAll(Extras.forTopic(o.topic))
            listOf("مقدمة", "تعريف الموضوع", "أهميته", "أبرز عناصره", "التطبيقات والأمثلة", "الخاتمة", "المصادر").forEach {
                out.add(Block.H(it)); out.add(Block.P("(اكتب هنا...)"))
            }
            progress(80)
            return out
        }

        val nImg = (if (o.images) 4 else 0) + o.extraImages.size
        var budget = ((o.pages - (if (cover) 1 else 0)) * cpp * 0.85).toInt()
        budget = (budget - nImg * cpp / 3).coerceAtLeast(cpp / 2)

        val lang = Wiki.lang(o.topic)
        progress(5)
        val titles = try { Wiki.search(o.topic, lang) } catch (e: Exception) { emptyList() }
        val secs = ArrayList<Pair<String, List<String>>>()
        var total = 0
        for (t in titles) {
            if (total >= budget) break
            val ps = try { Wiki.paragraphs(t, lang) } catch (e: Exception) { emptyList() }
            if (ps.isEmpty()) continue
            secs.add(t to ps)
            total += ps.sumOf { it.length }
            progress(10 + 60 * minOf(total, budget) / budget)
        }
        if (secs.isEmpty()) throw Exception("لم أجد معلومات عن الموضوع، جرّب صياغة ثانية")

        var left = budget
        fun addP(t: String) {
            if (left <= 0) return
            var s = t
            if (s.length > left) {
                val i = s.lastIndexOf('.', left)
                val cut = if (i < left / 2) left else i + 1
                s = s.substring(0, minOf(cut, s.length))
            }
            out.add(Block.P(s)); left -= s.length
        }

        out.add(Block.H("مقدمة"))
        addP(secs[0].second[0])
        out.addAll(Extras.forTopic(o.topic))
        for ((i, s) in secs.withIndex()) {
            if (left <= 0) break
            out.add(Block.H(s.first))
            if (o.images && i < 4) Wiki.image(s.first, lang)?.let { out.add(Block.Img(it)) }
            o.extraImages.getOrNull(i)?.let { out.add(Block.Img(it)) }
            val ps = if (i == 0) s.second.drop(1) else s.second
            for (p in ps) addP(p)
            progress(70 + 20 * (i + 1) / secs.size)
        }
        out.add(Block.H("الخاتمة"))
        out.add(Block.P("تناول هذا التقرير موضوع «${o.topic}» وعرض أبرز جوانبه ومفاهيمه الأساسية. ويتبين مما سبق أهمية الإلمام بهذا الموضوع، ويوصى بالرجوع إلى المصادر المذكورة للاستزادة."))
        out.add(Block.H("المصادر"))
        for (s in secs) out.add(Block.P("ويكيبيديا – ${s.first}: https://$lang.wikipedia.org/wiki/${URLEncoder.encode(s.first.replace(' ', '_'), "UTF-8")}"))
        return out
    }
}
