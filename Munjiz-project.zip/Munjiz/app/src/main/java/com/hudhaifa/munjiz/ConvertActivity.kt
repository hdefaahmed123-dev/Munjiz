package com.hudhaifa.munjiz

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class ConvertActivity : ComponentActivity() {
    private lateinit var status: TextView
    private var toPdf = true

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) convert(u)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screen("تحويل الملفات (بدون إنترنت)") {
            addView(tv("يحوّل النصوص والعناوين. الجداول والصور والتنسيق المعقد غير مدعومة حالياً.", 13f, false, Color.GRAY))
            addView(btn("Word ← PDF") { toPdf = true; pick.launch("*/*") })
            addView(btn("PDF ← Word") { toPdf = false; pick.launch("*/*") })
            status = tv("", 14f); addView(status)
        }
    }

    private fun convert(u: Uri) {
        status.text = "جارٍ التحويل..."
        Thread {
            try {
                val name = FileText.name(this, u).lowercase()
                if (toPdf && !name.endsWith(".docx")) throw Exception("اختر ملف Word بصيغة docx")
                if (!toPdf && !name.endsWith(".pdf")) throw Exception("اختر ملف PDF")
                val paras = FileText.paragraphs(this, u)
                if (paras.isEmpty()) throw Exception("ما لقيت نص بالملف")
                val blocks = paras.map { Block.P(it) }
                val rtl = paras.take(5).joinToString("").any { it in '\u0600'..'\u06FF' }
                val st = Style(rtl = rtl)
                val base = name.substringBeforeLast('.')
                runOnUiThread {
                    status.text = "تم التحويل ✅"
                    if (toPdf) Files.saveAndOpen(this, "$base.pdf", Files.PDF, PdfOut.build(blocks, st))
                    else Files.saveAndOpen(this, "$base.docx", Files.DOCX, Docx.build(blocks, st))
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "فشل: ${e.message}" }
            }
        }.start()
    }
}
