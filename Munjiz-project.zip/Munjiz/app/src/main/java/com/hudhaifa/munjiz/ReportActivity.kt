package com.hudhaifa.munjiz

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class ReportActivity : ComponentActivity() {
    private val extra = mutableListOf<ByteArray>()
    private lateinit var imgBtn: Button
    private var busy = false

    private val pick = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        for (u in uris) {
            try {
                val raw = contentResolver.openInputStream(u)?.use { it.readBytes() }
                if (raw != null) Docs.toJpeg(raw)?.let { extra.add(it) }
            } catch (e: Exception) { }
        }
        imgBtn.text = "🖼️ إضافة صور من الهاتف (${extra.size})"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val colors = listOf(
            "أسود" to Color.BLACK,
            "أزرق غامق" to Color.parseColor("#0D47A1"),
            "أحمر غامق" to Color.parseColor("#B71C1C"),
            "أخضر غامق" to Color.parseColor("#1B5E20")
        )
        screen("تقرير جديد") {
            val topic = edit("موضوع التقرير")
            val pages = spinner((1..50).map { "$it" }).apply { setSelection(4) }
            val size = spinner(listOf(10, 11, 12, 13, 14, 16, 18, 20, 24).map { "$it" }).apply { setSelection(4) }
            val col = spinner(colors.map { it.first })
            val bold = CheckBox(this@ReportActivity).apply { text = "خط عريض" }
            val imgs = CheckBox(this@ReportActivity).apply { text = "إضافة صور تلقائياً (يحتاج إنترنت)"; isChecked = true }
            val fmt = spinner(listOf("Word (.docx)", "PDF (.pdf)"))

            addView(topic)
            addView(tv("عدد الصفحات", 14f)); addView(pages)
            addView(tv("حجم الخط", 14f)); addView(size)
            addView(tv("لون الخط", 14f)); addView(col)
            addView(bold)
            addView(imgs)
            imgBtn = btn("🖼️ إضافة صور من الهاتف (0)") { pick.launch("image/*") }
            addView(imgBtn)
            addView(btn("🔎 اختيار صورة من قائمة بالأسماء") {
                val t = topic.text.toString().trim()
                if (t.isEmpty()) { topic.error = "اكتب الموضوع أولاً"; return@btn }
                if (!Net.online(this@ReportActivity)) {
                    Toast.makeText(this@ReportActivity, "هذا الخيار يحتاج إنترنت", Toast.LENGTH_SHORT).show(); return@btn
                }
                Thread {
                    try {
                        val l = Wiki.imageList(t, Wiki.lang(t))
                        runOnUiThread {
                            if (l.isEmpty()) {
                                Toast.makeText(this@ReportActivity, "ما لقيت صور لهذا الموضوع", Toast.LENGTH_SHORT).show()
                            } else {
                                android.app.AlertDialog.Builder(this@ReportActivity)
                                    .setTitle("اضغط على اسم الصورة لإضافتها")
                                    .setItems(l.map { it.first }.toTypedArray()) { _, i ->
                                        Thread {
                                            try {
                                                Docs.toJpeg(Net.bytes(l[i].second))?.let { extra.add(it) }
                                                runOnUiThread {
                                                    imgBtn.text = "🖼️ إضافة صور من الهاتف (${extra.size})"
                                                    Toast.makeText(this@ReportActivity, "تمت إضافة الصورة", Toast.LENGTH_SHORT).show()
                                                }
                                            } catch (e: Exception) { }
                                        }.start()
                                    }.show()
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this@ReportActivity, "تعذر جلب الصور", Toast.LENGTH_SHORT).show() }
                    }
                }.start()
            })

            val box = android.widget.LinearLayout(this@ReportActivity).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                visibility = View.GONE
            }
            val eUni = edit("الجامعة"); val eCol = edit("الكلية"); val eDep = edit("القسم")
            val eStu = edit("إعداد الطالب/ة"); val eSup = edit("بإشراف الأستاذ/ة")
            listOf(eUni, eCol, eDep, eStu, eSup).forEach { box.addView(it) }
            addView(tv("▼ بيانات الطالب والمشرف", 16f, true, Color.parseColor("#1565C0")).apply {
                setPadding(0, dp(12), 0, dp(8))
                setOnClickListener { box.visibility = if (box.visibility == View.GONE) View.VISIBLE else View.GONE }
            })
            addView(box)

            addView(tv("صيغة الملف", 14f)); addView(fmt)

            val status = tv("", 14f, true, Color.parseColor("#0D47A1")).apply { visibility = View.GONE }
            val bar = ProgressBar(this@ReportActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; visibility = View.GONE
            }

            addView(btn("إنشاء التقرير") {
                val t = topic.text.toString().trim()
                if (busy) return@btn
                if (t.isEmpty()) { topic.error = "اكتب الموضوع"; return@btn }
                busy = true
                status.visibility = View.VISIBLE; bar.visibility = View.VISIBLE
                status.text = "جارٍ إنشاء التقرير الآن..."
                bar.progress = 3
                val st = Style(size.selectedItem.toString().toFloat(), colors[col.selectedItemPosition].second, bold.isChecked)
                val o = Opts(
                    t, pages.selectedItem.toString().toInt(), st,
                    eUni.text.toString().trim(), eCol.text.toString().trim(), eDep.text.toString().trim(),
                    eStu.text.toString().trim(), eSup.text.toString().trim(),
                    imgs.isChecked, extra.toList()
                )
                val docx = fmt.selectedItemPosition == 0
                Thread {
                    try {
                        val online = Net.online(this@ReportActivity)
                        if (!online) runOnUiThread {
                            Toast.makeText(this@ReportActivity, "ماكو إنترنت: راح يتم إنشاء هيكل التقرير فقط", Toast.LENGTH_LONG).show()
                        }
                        val blocks = ReportGen.build(o, online) { p -> runOnUiThread { bar.progress = p } }
                        runOnUiThread { bar.progress = 92 }
                        val bytes = if (docx) Docx.build(blocks, st) else PdfOut.build(blocks, st)
                        val name = "تقرير_" + t.take(30).replace(Regex("[\\\\/:*?\"<>|\\n]"), "_") + (if (docx) ".docx" else ".pdf")
                        runOnUiThread {
                            bar.progress = 100
                            status.text = "تم إنجاز التقرير ✅"
                            Files.saveAndOpen(this@ReportActivity, name, if (docx) Files.DOCX else Files.PDF, bytes)
                            busy = false
                        }
                    } catch (e: Exception) {
                        runOnUiThread { status.text = "حدث خطأ: ${e.message}"; busy = false }
                    }
                }.start()
            })
            addView(status)
            addView(bar)
        }
    }
}
